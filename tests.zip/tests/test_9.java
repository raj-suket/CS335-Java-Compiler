public class append{
    int x;
    float y;
        
    int fun(int a, float b){
        
        return a;
    }

    int funaa(){
        int c = fun(x, y);
    }
}