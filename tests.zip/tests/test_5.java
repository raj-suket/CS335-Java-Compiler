public class test_5 {
    static float hell(double y, int z)
    {
        return 1;
    }
    public static void main(){
        float y = hell(1.0);
    }   
}
