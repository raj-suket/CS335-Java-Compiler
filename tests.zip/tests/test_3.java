public class best{
    int x;
    float y;
    boolean z;

    public int fun(int a, float b, boolean z);

    public boolean main(){
        int g = 1;
        float h = 1.1;
        boolean j = true;

        int finy = fun(x, y ,z) + fun(g, h, j);
    }
}