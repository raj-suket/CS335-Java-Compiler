public class test_8 {
    public static void main()    
    {
        int x = 1;
        while(x<7)
        {
            if(x==5)
            {
                continue;
            }
            x++;
        }
    }
}
