public class test_2 {
    static int sum(int a, int b)
    {
        if(a==1)
        {
            return 1;
        }
        return 0;
    }
    public static void main()
    {
        int x = sum(1,2);
    }
}
