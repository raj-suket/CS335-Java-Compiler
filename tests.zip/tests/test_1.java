<<<<<<< HEAD
public class test_1 {
    float func(int a, int b)
    {
        int c = 1;
        int c = 2;
        if(c==1)
        {
            c++;
        }
=======
public class append{
    int sum(int a, int b){
        float x;
        return 1;
    }
    float hell(int c){
        double y;
        return 1;
>>>>>>> ab7865be000990454a15cddfe4d1c017015335ec
    }
    public static void main()
    {
        int x = 1;
    }
}
