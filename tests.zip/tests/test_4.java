public class test_4 {
    static float hell(double y, int z)
    {
        return 1;
    }
    public static void main()
    {
        int x = "Error";
        float y = hell(1.0, 2);
    }
}
