public class test_0 {
    long f1;
    short f2;
    int sum(int a, double b)
    {
        float x;
        return 1;
    }
    float  hell(char c)
    {
        return 2.0;
    }
    public static void main() {
        double x = 3.0;
        test_0 A = new test_0();
        int y = A.sum(1,x);
    }
}
