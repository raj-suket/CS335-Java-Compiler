public class test_6 {
    public static void main()
    {
        if(true)
        {
            var y = "Yes";
        }else
        {
            var z = "No";
            if(false) 
            {
                int f = 1;
            }
        }
    }
}
